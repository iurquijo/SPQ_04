var searchData=
[
  ['introducefilm',['introduceFilm',['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_play_list.html#a9b9a595d6958ef69d3109fd2bf6e09ff',1,'com.moviemanager.server.jdo.PlayList.introduceFilm(Movie film, int position)'],['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_play_list.html#a4dc1856ea68e1e0444fcf9c858f3bad6',1,'com.moviemanager.server.jdo.PlayList.introduceFilm(Movie film)']]]
];
