var searchData=
[
  ['actor',['Actor',['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_actor.html',1,'com::moviemanager::server::jdo']]],
  ['actor',['Actor',['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_actor.html#ac4b7149b5d78f30763c5b1f4d88216cb',1,'com.moviemanager.server.jdo.Actor.Actor()'],['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_actor.html#a428a6382edfcd5b0fe90d87eca04546c',1,'com.moviemanager.server.jdo.Actor.Actor(String name, String surname, List&lt; Movie &gt; moviesActor)']]],
  ['addratetomovie',['addRateToMovie',['../classcom_1_1moviemanager_1_1server_1_1_d_a_o_1_1_movie_advisor_d_a_o.html#a880eb6ea5746a0bee7339dd216d02735',1,'com::moviemanager::server::DAO::MovieAdvisorDAO']]],
  ['adduser',['addUser',['../classcom_1_1moviemanager_1_1server_1_1_d_a_o_1_1_movie_advisor_d_a_o.html#a197892868f27e951d50181c66b8e75e5',1,'com::moviemanager::server::DAO::MovieAdvisorDAO']]],
  ['apptest',['AppTest',['../classcom_1_1moviemanager_1_1app_1_1_app_test.html#a287b77593d240528addb3f91eb119e46',1,'com::moviemanager::app::AppTest']]],
  ['apptest',['AppTest',['../classcom_1_1moviemanager_1_1app_1_1_app_test.html',1,'com::moviemanager::app']]]
];
