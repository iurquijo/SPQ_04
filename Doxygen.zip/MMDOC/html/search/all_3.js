var searchData=
[
  ['findbutton',['findButton',['../classcom_1_1moviemanager_1_1client_1_1_grafical_interfaces_1_1_main.html#acec0a3d468b2932bfdb91c68c01302bc',1,'com::moviemanager::client::GraficalInterfaces::Main']]]
];
