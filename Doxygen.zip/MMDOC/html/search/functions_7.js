var searchData=
[
  ['playlist',['PlayList',['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_play_list.html#a128a9ac3971f933e3a8f503b8fa9aec0',1,'com.moviemanager.server.jdo.PlayList.PlayList()'],['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_play_list.html#ab6c35093ee7634588599d03587921d07',1,'com.moviemanager.server.jdo.PlayList.PlayList(String name)']]]
];
