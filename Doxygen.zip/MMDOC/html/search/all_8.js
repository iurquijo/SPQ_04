var searchData=
[
  ['openmoviebutton',['openMovieButton',['../classcom_1_1moviemanager_1_1client_1_1_grafical_interfaces_1_1_main.html#a3424bf21492d5b08e8f3013b55e180b1',1,'com::moviemanager::client::GraficalInterfaces::Main']]]
];
