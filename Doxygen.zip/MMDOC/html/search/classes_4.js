var searchData=
[
  ['login',['Login',['../classcom_1_1moviemanager_1_1client_1_1_grafical_interfaces_1_1_login.html',1,'com::moviemanager::client::GraficalInterfaces']]]
];
