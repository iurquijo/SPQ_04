var searchData=
[
  ['iserver',['IServer',['../interfacecom_1_1moviemanager_1_1server_1_1_i_server.html',1,'com::moviemanager::server']]],
  ['iuserdao',['IUserDAO',['../interfacecom_1_1moviemanager_1_1server_1_1_d_a_o_1_1_i_user_d_a_o.html',1,'com::moviemanager::server::DAO']]]
];
