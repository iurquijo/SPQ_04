var searchData=
[
  ['register',['Register',['../classcom_1_1moviemanager_1_1client_1_1_grafical_interfaces_1_1_register.html',1,'com::moviemanager::client::GraficalInterfaces']]],
  ['rmiservicelocator',['RMIServiceLocator',['../classcom_1_1moviemanager_1_1client_1_1_grafical_interfaces_1_1remote_1_1_r_m_i_service_locator.html',1,'com::moviemanager::client::GraficalInterfaces::remote']]]
];
