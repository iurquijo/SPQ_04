var searchData=
[
  ['server',['Server',['../classcom_1_1moviemanager_1_1server_1_1_server.html',1,'com::moviemanager::server']]]
];
