var searchData=
[
  ['usernamelabel',['UserNameLabel',['../classcom_1_1moviemanager_1_1client_1_1_grafical_interfaces_1_1_main.html#a41fdfc17f99ec750aa370775f552ed56',1,'com::moviemanager::client::GraficalInterfaces::Main']]]
];
