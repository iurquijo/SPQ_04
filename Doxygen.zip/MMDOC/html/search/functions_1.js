var searchData=
[
  ['comment',['Comment',['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_comment.html#aa7073a4d439dc06471b421ce28967baf',1,'com::moviemanager::server::jdo::Comment']]],
  ['createdatabase',['createDatabase',['../classcom_1_1moviemanager_1_1server_1_1_d_a_o_1_1_movie_advisor_d_a_o.html#a314c4c9accc0124ac1a008c182e6fe72',1,'com::moviemanager::server::DAO::MovieAdvisorDAO']]]
];
