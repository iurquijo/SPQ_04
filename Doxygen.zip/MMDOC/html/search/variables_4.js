var searchData=
[
  ['panel',['panel',['../classcom_1_1moviemanager_1_1client_1_1_grafical_interfaces_1_1_login.html#a1d867c91adebd9cae15e73b08cd0c68f',1,'com.moviemanager.client.GraficalInterfaces.Login.panel()'],['../classcom_1_1moviemanager_1_1client_1_1_grafical_interfaces_1_1_main.html#a89306bfd75db1ebb9fc07acfad8d5772',1,'com.moviemanager.client.GraficalInterfaces.Main.panel()']]]
];
