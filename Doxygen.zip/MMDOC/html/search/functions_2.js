var searchData=
[
  ['delegate_5fmain',['Delegate_Main',['../classcom_1_1moviemanager_1_1client_1_1_grafical_interfaces_1_1_delegate___main.html#ae32a81203ec09d08d9b154780e6311fc',1,'com::moviemanager::client::GraficalInterfaces::Delegate_Main']]],
  ['director',['Director',['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_director.html#ac08942a7dd947273ee6cc791826bec2d',1,'com.moviemanager.server.jdo.Director.Director()'],['../classcom_1_1moviemanager_1_1server_1_1jdo_1_1_director.html#a3cf0fc48b0f71a08036cc9bd2aed7b69',1,'com.moviemanager.server.jdo.Director.Director(String name, String surname, List&lt; Movie &gt; moviesDirector)']]]
];
